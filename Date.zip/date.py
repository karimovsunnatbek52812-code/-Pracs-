import datetime
import weekdays
import digits

def main ():
	print("Давайте определим дату вашего рождения!")

	day = validate_int_input("День (дд): ", 2)
	month = validate_int_input("Месяц (мм): ", 2)
	year = validate_int_input("Год (гггг): ", 4)

	date = datetime.date(year, month, day)
	weekday = weekdays.l[date.weekday()]
	leap_year_state = True if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0) else False
	leap_year = "Да" if leap_year_state else "Нет"
	today = datetime.date.today()
	age = today.year - year
	if (today.month, today.day) < (month, day):
		age-=1
	print(f"\
---- ---- ---- --- --- ---\n\
--- Информация по вашей дате рождения:\n\
--- --- День недели: {weekday}\n\
--- --- Високосный год: {leap_year}\n\
--- --- Возраст: {age}\n\
---- ---- ---- --- --- ---")
	date_str = f"{day:02d} {month:02d} {year}"
	print_big_digits(date_str)
	end = input("НАЖМИТЕ ЛЮБУЮ КНОПКУ ЧТО БЫ ЗАКОНЧИТЬ")

def print_big_digits(text):
	rows = [""] * 5
	for char in text:
		if char == " ":
			for i in range(5):
				rows[i] += "   "
		else:
			digit = digits.l.get(char, [""]*5)
			for i in range(5):
				rows[i] += digit[i] + "  "

	for row in rows:
		print(row)


def validate_int_input(text, length):
	str_length = str(length)
	if not str_length.isdigit():
		print("Error on func ::validate_int. Length not digit.")


	while True:
		data = input(text)
		if len(str(data)) == length and data.isdigit():
			return int(data)
		else:
			print("Введите именно {length} цифры".format(length=length))

main()